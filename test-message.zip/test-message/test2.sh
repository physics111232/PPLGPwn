send_notifications() {
    local message=$1
    while true; do
        luna-send -f -n 1 luna://com.webos.notification/createToast "{\"message\": \"$message\"}"
        sleep 2  # Wait for 2 seconds before sending the next notification
    done
}

# Start sending notifications
send_notifications "<b>Test Notification</b><br/>This is a test message being sent repeatedly."