# send notification
luna-send -f -n 1 luna://com.webos.notification/createToast '{"message": "<p style="color: FFFF00;">Working!</p>"}'