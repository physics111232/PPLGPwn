# send notification
luna-send -f -n 1 luna://com.webos.notification/createToast '{"message": "<b>Working!</b>"}'